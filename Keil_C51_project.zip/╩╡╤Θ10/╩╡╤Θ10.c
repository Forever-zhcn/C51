#include "reg51.h"
#define uchar unsigned char
#define uint unsigned int
#define out  P1
sbit start=P2^1;
sbit oe=P2^7;
sbit eoc=P2^3;
sbit clock=P2^0;
sbit add_a=P2^4;
sbit add_b=P2^5;
sbit add_c=P2^6;

uchar code tab[]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f};
uchar c=0x01;
uchar seg[4];

void delay(uint i)
{
	uchar j=250;
	for(;i>0;i--)
	{
		while(--j);
		j=249;
		while(--j);
		j=250;
	}
}

void show()
{
	uchar a;
	for(a=0;a<4;a++)
	{
		P0=(c<<a);	
		P3=seg[a];
		if(a==2)
		{
			P3=P3|0x80;
		}
		delay(1);
	}
}


void main(void)
{
	uint addata;
	 
	while(1)
		{
			add_a=0;
			add_b=0;
			add_c=0; 
			start=1;
			start=0;  //����ת��
			while(1)
			{
				clock=!clock;
				if(eoc==1)break;
				oe=1;	     //�������
				addata=out;
				addata=addata*1.96;
				seg[0]=tab[addata%10];
				seg[1]=tab[addata/10%10];
				seg[2]=tab[addata/100%10];
				seg[3]=tab[addata/1000];	 
				show();
				oe=0;	  //�ر����
			}
		}
}