#include<reg51.h>
sbit p1_0=P1^0;
sbit p1_1=P1^1;
void main(void)
{
	TMOD=0x11;
	TR0=1;
	TR1=1;
	while(1)
	{
			TH0=0xfc;
			TL0=0x18;
			TH1=0xfe;
			TL1=0x0c;
		do
		{
		}while(!TF0&&!TF1);
		p1_0=~p1_0;
		p1_1=~p1_1;
		TF0=0;	
	}
}
