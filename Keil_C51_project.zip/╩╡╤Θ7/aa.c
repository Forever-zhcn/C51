#include <reg51.h>
#define uint unsigned int

sbit p2_0 = P1^0;
sbit p2_1 = P1^1;


void main()
{
    TMOD= 0x11;       
    TH0 = 0xfe;           // 65536-500
    TL0 = 0x0c;
    TH1 = 0xfc;			  //	65536-1000
    TL1 = 0x18;
    TR0 = 1;           
    TR1 = 1;
	
    while(1)
    {   
       // uint a,b;
        if(TF0 == 1)
        {
            TH0 = 0xfe;           // ��������ֵ
            TL0 = 0x0b; 
			p2_0=~p2_0;         
            //a = ~a;
			TF0 = 0;
			
            
        }
        if(TF1 == 1)
        {
            TH1 = 0xfc;           // ��������ֵ
            TL1 = 0x18;
			p2_1=~p2_1;
            //b = ~b;
			TF1 = 0;
        }

        //p2_0 = a;
        //p2_1 = b;
    }
}
