#include<reg51.h>
#define uchar unsigned char
void main()
{
	TMOD=0x01;
	TH0=0xee;
	TL0=0x00;
	P1=0x00;
	EA=1;
	ET0=1;
	TR0=1;
	while(1);
	{
  	 ;
	}
}


void timer0() interrupt 1 using 0
{
	uchar i;
	TH0=0xee;
	TL0=0x00;
	i--;
	if(i==0)
	{
		P1=~P1;
		i=200;
	}		
}
