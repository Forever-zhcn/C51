#include<reg52.h>
#define uchar unsigned char
#define uint unsigned int

uchar tab[]={0xfe,0xfd,0xfb,0xf7,0xef,0xdf,0xbf,0x7f};
uchar a;
void delay(uint i)
{
	uchar j=250;
	for(;i>0;i--)
	{
		while(--j);
		j=249;
		while(--j);
		j=250;
	}
	
}
void main()
{
	TMOD=0x20;
	SCON=0x50;   
	PCON=0x00;   //SMOD=0;
	TH1=0xfd;
	TL1=0xfd;
	TR1=1;
	EA=1;
	ES=1;
	while(1)
	{
	
	}
}

void UART() interrupt 4
{
	RI=0;  //���յ����ݺ󣬽� RI �� 0
}


