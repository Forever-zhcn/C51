#include<reg51.h>
#include <intrins.h>
#define uchar unsigned char
#define uint unsigned int
#define uchar unsigned char
#define uint unsigned int
#define out P0

void delay(uint j);
void check_busy(void);
void write_command(uchar com);
void write_data(uchar dat);
void lcd_initial(void);
void string(uchar ad,uchar *s);
void clock_init();

void clock_write(uint s,uint m,uint h);



uint t;	 
uchar miao;
uchar fen;
uchar shi;


sbit K2=P3^3;
sbit K3=P3^4;
sbit K4=P3^5;
sbit RS=P2^0;
sbit RW=P2^1;
sbit E =P2^2;



void main()
{
    lcd_initial(); 	 //Һ������ʼ����������
	clock_init();	 //ʱ�ӳ�ʼ����������

	TMOD=0x01;
	EA=1;

	PX0=1;
	PT0=0;

	ET0=1;
	EX0=1;
	IT0=1;		//�½��ش���

	TH0=0xee;		 //5ms
	TL0=0x00;
	TR0=1;

	t=0;
	miao=0;
	fen=0;
	shi=0; 

  while(1)
	{
	clock_write(shi,fen,miao);
	}
}


void delay(uint j)
{
   uchar i=250;
   for(;j>0;j--)
   {
    while(--i);
	  i=249;
	  while(--i);
	  i=250;
   }
}


void check_busy(void)	 //���æ
{
   uchar dt;
   do
   {
    dt=0xff;
	  E=0;
	  RS=0;
	  RW=1;
	  E=1;
	  dt=out;
   }
   while(dt&0x80);
   E=0;
}


void write_command(uchar com)	//д����	 	
{
   check_busy();
   E=0;
   RS=0;
   RW=0;
   out=com;
   E=1;
   _nop_();
   E=0;
   delay(1);
}

void write_data(uchar dat)	  //д��ʾ����
{
   check_busy();
   E=0;
   RS=1;
   RW=0;
   out=dat;
   E=1;
   _nop_();
   E=0;
   delay(1);
}


void lcd_initial(void)			 //LCD����ʾ��ʼ������
{
   write_command(0x38);
   _nop_();
   write_command(0x0c);
	 _nop_();
   write_command(0x04);
	 _nop_();
   write_command(0x01);
   delay(1);
}


void string(uchar ad,uchar *s)	 //�����ʾ�ַ���
{
   
   while(*s!='\0')
   {   
		write_command(ad);
		write_data(*s++);
		ad++;
   }
}


void clock_init()       //ʱ�ӳ�ʼ��
{
  string(0x81,"Time:");  
  string(0xc4,"00:00:00");       
}


uchar miao=0,fen=0,shi=0;
uchar code tab[]={0x30,0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39};

void write_sfm(uchar add,uchar date)   //deae=h����m����s  ����
{
  uchar ge,shi;
	shi=tab[date/10];
	ge=tab[date%10];
  write_command(add);		//д��λ��
	write_data(shi); 	
  write_command(add+0x01);
	write_data(ge);		
}

			   //shi    fen    miao
void clock_write(uint h,uint m,uint s)  //Сʱ���֣���
{
  write_sfm(0xc4,h);  //0xc4,0xc7,0xca���û�add
  write_sfm(0xc7,m);
  write_sfm(0xca,s);	
}


void T0_int(void) interrupt 1
{	
	TH0=0xee;
	TL0=0x00;
  	t++;
	if(t==200)
	{
		t=0;
		miao++;
	}

	if(miao==60)
	{
		miao=0;
		fen++;
	}

	if(fen==60)
	{
		fen=0;
		shi++;
	}

	if(shi==24)
	{
	  shi=0;
	}	
}



void int0_Key(void) interrupt 0	   //����K1�����ⲿ�ж�0
{
  while(K4!=0)
	{
		EA=0;
	  	if(K2==0)
		{
		  delay(10);
			if(K2==0)
			{
				delay(200);
				shi++;
				miao=0;
				if(shi==24)
					{
			  		shi=0;
					}

			clock_write(shi,fen,miao);
			}
		}

		if(K3==0)
		{
		  	delay(10);
			if(K3==0)
			{
				delay(200);
				fen++;
				miao=0;
				if(fen==60)
			  	{
			  	fen=0;
			  	}

			clock_write(shi,fen,miao);
			}
		}
	}
	EA=1;
}
