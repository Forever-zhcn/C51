#include <reg51.h>
//#include <intrins.h>
#define uchar unsigned char
#define uint unsigned int
#define OUT P0
#define Key P1

uchar code seg[]={0x40,0x79,0x24,0x30,0x19,0x12,0x02,0xf8,0x00,0x10,0x88,0x83,0xc6,0xa1,0x86,0x8e};
void delay(uint i);
uchar KeyScan(void);//����ɨ�躯��
uchar KeyPro(void); //��ֵ���غ���
void main(void)
{
        uchar num;
        for(;;)
        {
               
                num=KeyPro();		
                if(KeyPro()!=0xff)
                OUT=seg[num];		//���
        }
}
void delay(uint i)
{
        uchar t;
        while(i--)
        {
                for(t=0;t<120;t++);
        }
}





uchar KeyScan(void)  
{
        unsigned char cord_h,cord_l;
        Key=0x0f;                   
        delay(10);              
        if((Key&0x0f)!=0x0f)
        {
			cord_l=Key&0x0f;     //	00001111
			Key=cord_l|0xf0;  	 //00001111|11110000=11111111 
			cord_h=Key&0xf0;  	 //11111111&11110000=11110000
            return(cord_h+cord_l);	
        }
        
}



uchar KeyPro(void)
{
        switch(KeyScan())
        {
        case 0x7e:return 0;break;//0 ������Ӧ�ļ�������Ӧ��ֵ
        case 0xbe:return 1;break;//1
        case 0xde:return 2;break;//2
        case 0xee:return 3;break;//3
		case 0x7d:return 4;break;//4
        case 0xbd:return 5;break;//5
        case 0xdd:return 6;break;//6
        case 0xed:return 7;break;//7
        case 0x7b:return 8;break;//8
        case 0xbb:return 9;break;//9
        case 0xdb:return 10;break;//a
        case 0xeb:return 11;break;//b
        case 0x77:return 12;break;//c
        case 0xb7:return 13;break;//d
        case 0xd7:return 14;break;//e
        case 0xe7:return 15;break;//f
        default:return 0xff;break;
        }
}