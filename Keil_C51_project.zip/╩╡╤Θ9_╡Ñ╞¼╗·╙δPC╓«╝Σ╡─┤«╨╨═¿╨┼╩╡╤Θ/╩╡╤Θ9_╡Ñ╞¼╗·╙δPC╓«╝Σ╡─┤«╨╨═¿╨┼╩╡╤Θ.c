#include<reg52.h>
#define uchar unsigned char
#define uint unsigned int

uchar tab[]={0xfe,0xfd,0xfb,0xf7,0xef,0xdf,0xbf,0x7f};
void delay(uint i)
{
	uchar j=250;
	for(;i>0;i--)
	{
		while(--j);
		j=249;
		while(--j);
		j=250;
	}
	
}
void main()
{
	TMOD=0x20;
	SCON=0x40;   //只发送
	PCON=0x00;   //SMOD=0;
	TH1=0xfd;
	TL1=0xfd;
	TR1=1;
	EA=1;
	ES=1;
	while(1)
	{
		uchar m;
		for(m=0;m<8;m++)
		{
			SBUF=tab[m];
			while(TI==0);
			TI=0;
			delay(20);
		}
		while(1);
	}
}




