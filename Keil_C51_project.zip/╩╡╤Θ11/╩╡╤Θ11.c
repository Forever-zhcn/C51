#include<reg52.h>
#include<intrins.h>
#define uchar unsigned char
#define uint unsigned int
sbit INC=P3^4;
sbit DEC=P3^5;
sbit out1=P3^6;
sbit out2=P3^7;
sbit k1=P1^0;
sbit k2=P1^1;

uint PWM=900;
void delay(uint i)
{
	for(;i>0;i--)
	{
		_nop_();
	}
}
void main()
{
	out1=1;
	while(1)
	{
		
		out1=1;
		if(!INC)
				PWM=PWM>0 ? PWM-20 :0;
		if(!DEC)
				PWM=PWM<1000 ? PWM+20 :1000;
		out2=1;
		delay(PWM);
		out2=0;
		delay(1000-PWM);
		
	}
}