#include<reg51.h>
#define uchar unsigned char
void main()
{
	TMOD=0x05;
	TH0=0xff;
	TL0=0xff;
	P1=0xff;
	EA=1;
	ET0=1;
	TR0=1;
	while(1);
	{
  	 ;
	}
}

uchar temp=0xfe;
uchar key=0;

void timer0() interrupt 1 using 0
{
	TH0=0xff;
	TL0=0xff;
	P1=temp;
	key++;
	temp=temp<<1;
	if(key>8)
	{
		P1=0xfe;
		key=0;
		temp=P1;
	}		
}
