#include <reg51.h>
#include <intrins.h>
#define uchar unsigned char
#define uint unsigned int
uchar code seg[]={0x40,0x79,0x24,0x30,0x19,0x12,0x02,0xf8,0x00,0x10};

void delayms(uint j)
{												 	
 	uchar i;
	while(--j)
	for(i=100;i>0;i--);
}

void main()
{
 	uchar i=0;
	while(1)
	{
	 	P0=seg[i];
		i=i+1;	
		delayms(500);
		if(P0==0x10)i=0;
	}
}
