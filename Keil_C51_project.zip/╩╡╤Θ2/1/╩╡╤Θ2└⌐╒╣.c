#include <reg51.h>
#define uchar unsigned char
#define uint unsigned int
sbit in0=P3^2;
sbit in1=P3^3;
uchar code seg[]={0x40,0x79,0x24,0x30,0x19,0x12,0x02,0xf8,0x00,0x10};
uchar code seg2[]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f};

void delayms(uint j)
{
 	uchar i;
	while(j--)
	for(i=100;i>0;i--)
	;
}

void main()
{
	while(1)
	{
		if(in0==1||in1==1)P0=0xff;P2=0x00;
		if(in0==0)
		{
		 	uchar p=0,q=0;
			uchar a;
			for(a=0;a<10;a++)
			{
			 	P0=seg[p];	 //��������������
				P2=seg2[q];	 //��������������
				p++;
				q++;	
				delayms(500);
				if(P0==0x10)
				p=0;
				if(P2==0x6f)
				p=0;

			}
		}
		if(in1==0)
		{
		 	uchar m=9,n=9;
			uchar b;
			for(b=0;b<9;b++)
			{
			 	P0=seg[m];
				P2=seg2[n];
				m--;
				n--;	
				delayms(500);
				if(P0==0x40)
				m=9;
				if(P2==0x3f)
				m=9;
			}
		}
	}	
}
