#include<reg51.h>
#include"instrins.h"
#define uchar unsigned char
sbit in=P3^0;
void main(void)
{
      while(1)
	{
		in=1;
		if(in==0)
		P1=0xfe;
		else
		P1=0xff;
	}
}