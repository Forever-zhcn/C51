#include<reg51.h>
#include<intrins.h>
#define uchar unsigned char
sbit in=P3^0;

void delay(void)
{
	uchar i,j;
	for(i=0;i<100;i++)
	for(j=0;j<100;j++)
	;
}

void main(void)
{
	uchar a;
	while(1)
		{
		if(in==1)
			{
				P1=0xfe;
				for(a=0;a<8;a++)
				{
					delay();
					P1=_crol_(P1,1);
				}
			}
		if(in==0)
			{
				P1=0xf0;
				delay();
				P1=0x0f;
				delay();	
			}
		}
}
