#include <reg51.h>
#include <intrins.h>
#define uchar unsigned char
#define uint unsigned int

void delay(uint j)
{
	uchar i=250;
	for(;j>0;j--)
	{
		while(--i);
		i=249;
		while(--i);
		i=250;
	}
}

void main(void)
{
	EA=1;
	EX0=1;
	IT0=1;
	while(1)
	{
		P1=0xff;
		delay(500);
		P1=0x00;
		delay(500);	
	}
}
void int0(void) interrupt 0 using 0
{
	uchar a;
	P1=0xfe;
	for(a=0;a<8;a++)
	{
		delay(500);
		P1=_crol_(P1,1);
	}			
}