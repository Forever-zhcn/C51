#include <reg51.h>
#define uchar unsigned char
#define uint unsigned int

uint time;
uchar code seg[]={0x40,0x79,0x24,0x30,0x19,0x12,0x02,0xf8,0x00,0x10};


void main()
{
	TMOD=0x01;
	TH0=0xee;
	TL0=0x00;
	EA=1;
	ET0=1;
	TR0=1;
	while(1)
	{
	;
	}
}

char t=0;
void t0() interrupt 1
{
	TH0=0xee;
	TL0=0x00;
	t++;
	if(t==20)
	{
		t=0;
		time++;
		P0=seg[time/100];
		if(time<100)
		{
		P2=seg[time/10];
		}
		if(time>=100)
		{
		P2=seg[time/10%10];
		}
		P1=seg[time%10];
		if(time>600)
		{
		time=0;
		}
	}
}